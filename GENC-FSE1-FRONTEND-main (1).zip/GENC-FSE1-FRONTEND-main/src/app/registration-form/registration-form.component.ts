import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { LoginService } from '../login.service';
import { UserService } from '../profile/user/user.service';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { UserDetail } from './user-detail';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-registration-form',
  templateUrl: './registration-form.component.html',
  styleUrls: ['./registration-form.component.css']
})
export class RegistrationFormComponent implements OnInit {
  
  message: string = ''

  regForm : FormGroup;

  submitted : boolean = false;

  constructor(private userService: UserService, private loginService: LoginService, private formBuilder:FormBuilder,private route: ActivatedRoute,private router: Router) { 
    this.regForm = this.formBuilder.group({
      username : new FormControl(null,[Validators.required, Validators.pattern('^[a-zA-Z0-9.]{8,20}$')]),
      firstName : new FormControl(null,[Validators.required]),
      lastName : new FormControl(null,[Validators.required]),
      email : new FormControl(null,[Validators.required, Validators.pattern('[a-zA-Z0-9]+@[a-zA-Z]+\.[a-zA-Z]{2,3}')]),
      contactNo : new FormControl(null,[Validators.required, Validators.pattern('^[1-9][0-9]{9}$')]),
      password : new FormControl('',[Validators.required, Validators.pattern('^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z]).{8,}$')]),
      confirmPassword : new FormControl('',[Validators.required]) 
    },
    {
      validators:this.passwordMatch('password','confirmPassword')
    })

  }

  formData : UserDetail = new UserDetail();

  get f (){return this.regForm.controls}

  passwordMatch(originalPassword:string,renteredPassword:string){
    return(formGroup:FormGroup)=>{
        const passwordControl = formGroup.controls[originalPassword];
        const reneteredPasswordControl = formGroup.controls[renteredPassword];

        if(reneteredPasswordControl.errors && !reneteredPasswordControl.errors?.['passwordMatch']){
          return;
        }
        if(passwordControl.value != reneteredPasswordControl.value){
          reneteredPasswordControl.setErrors({passwordMatch:true});
        }
        else{
          reneteredPasswordControl.setErrors(null);
        }
    }
  }
  
  ngOnInit(): void {
  }

  /*register(formData: NgForm){
    this.userService.register(formData.value)
      .subscribe((response:any) => {
        if(response.status == 201)
          this.loginService.login(formData.value);
      },
      (error:any) => {
          alert(error.error.msg);
      });
  }*/
  register(){
    this.submitted = true;
    if(this.regForm.invalid){
      return;
    }
    this.formData.firstName = this.regForm.value.firstName;
    this.formData.lastName = this.regForm.value.lastName;
    this.formData.email = this.regForm.value.email;
    this.formData.contactNo = Number(this.regForm.value.contactNo);
    this.formData.username = this.regForm.value.username;
    this.formData.password = this.regForm.value.password;
    this.userService.register(this.formData)
      .subscribe((response:any) => {
        if(response.status == 201)
          alert("Registration Successfull!!");
          this.loginService.login(this.formData);
      },
      (error:any) => {
          alert(error.error.msg);
      });
  }
}
