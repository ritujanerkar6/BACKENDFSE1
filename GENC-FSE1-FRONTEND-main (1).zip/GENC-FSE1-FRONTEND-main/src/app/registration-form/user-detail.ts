export class UserDetail {
    firstName : string = '';
        
    lastName : string = '';
        
    email : string = '';
        
    username : string = '';
        
    password : string = '';
        
    contactNo : number = 0;
}
