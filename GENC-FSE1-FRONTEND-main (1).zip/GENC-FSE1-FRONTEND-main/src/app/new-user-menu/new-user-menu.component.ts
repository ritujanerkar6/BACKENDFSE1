import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'new-user-menu',
  templateUrl: './new-user-menu.component.html',
  styleUrls: ['./new-user-menu.component.css']
})
export class NewUserMenuComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
