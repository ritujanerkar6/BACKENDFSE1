import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NewUserMenuComponent } from './new-user-menu.component';

describe('NewUserMenuComponent', () => {
  let component: NewUserMenuComponent;
  let fixture: ComponentFixture<NewUserMenuComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NewUserMenuComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(NewUserMenuComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
