import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ProfileService {

  tweets: BehaviorSubject<any> = new BehaviorSubject<any>([]);
  constructor() { }
  addTweet(tweet:any){
    const tweets = this.tweets.getValue();
    tweets.push(tweet);
    this.tweets.next(tweets);
  }
}
